import React from 'react';
import { Route, Routes } from 'react-router-dom'; 
import { Orders } from '../Orders/Orders';
import { AdminSideBar } from './AdminSideBar';
import { Navbar } from './Navbar/Navbar';  
import { Complains } from '../Complains/Complains';
import { Dashboard } from '../Dashbpard/Dashboard';

export const Admin = () => {
  const handleClose = () => {};

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar />
      <div style={{ display: 'flex', flexGrow: 1 }}>
        <AdminSideBar handleClose={handleClose} />
        <div style={{ flexGrow: 1, padding: '20px', marginLeft: '20vw', marginTop: '0' }}>
          <Routes>
            <Route path='/' element={<Dashboard/>} />
            <Route path='/orders' element={<Orders />} />  
            <Route path='/complains' element={<Complains/>} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

