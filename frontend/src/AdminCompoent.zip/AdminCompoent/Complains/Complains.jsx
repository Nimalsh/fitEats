import React from 'react'

export const Complains = () => {
  return (
    <div>Complains</div>
  )
}
